function toggleReadMore() {
    const moreText = document.getElementById("moreText");
    const readbtn = document.getElementById("readbtn");

    if (moreText.style.display === "none") {
        moreText.style.display = "block";
        readbtn.innerText = "Read Less";
    } else {

    moreText.style.display = "none";
    readbtn.innerText = "Read More";
    }
}