function performSearch() {
    const query = document.getElementById('searchInput').value.trim().toLowerCase();
    if (!query) {
        alert('please enter a search term');
        return;
    }

    const sections = document.querySelectorAll('section');
    let found = false;

    sections.forEach(section => {
        const heading = section.querySelector('h1').textContent.toLowerCase();
        const content = section.textContent.toLowerCase();

        // Check if query matches the section heading or content
        if (heading.includes(query) || content.includes(query)) {
          found = true;
          section.scrollIntoView({ behavior: 'smooth' });
          section.style.backgroundColor = '#ffffcc'; // Highlight matching section
          setTimeout(() => section.style.backgroundColor = '', 2000); // Remove highlight after 2s
        }
      });

      if (!found) {
        alert('No results found.');
      }
    }


