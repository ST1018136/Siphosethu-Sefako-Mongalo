/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.quickchatapp;

/**
 *
 * @author sethu
 */

import java.util.Random;

public class Message {
    private String messageId;
   private String sender;
   private String recipient;
   private String content;
   
   public Message(String recipient, String content){
       this.messageId = generateMessageId();
       this.recipient = recipient;
       this.content = content;
   }
   
   private String generateMessageId(){
       Random random = new Random();
       return String.format("%010d", random.nextInt(1000000000));
   }
   
   public String sentMessage(){
       if (content.length()> 250){
           return "please enter a message less than 250 characters";
       }
       return "Message has been sent";
   }
   
   public String createMessageHash(){
       String[] words = content.split("\\s+");
       String firstTwoLetters = content.substring(0, Math.min(2, content.length()));
       String firstWord = words.length > 0 ? words[0] : "";
       String lastWord = words.length > 1 ? words[words.length-1] : firstWord;
       return (firstTwoLetters + ":" + firstWord + lastWord).toUpperCase();
   }
   // getters
   public String getMessageId() {
       return messageId;
   }
   public String getSender(){
       return sender;
   }
   public String getRecipient(){
       return recipient;
   }
   public String getContent(){
       return content;
   }
   
   // Setters
   public void setSender(String sender){
       this.sender = sender;
   }
   
}