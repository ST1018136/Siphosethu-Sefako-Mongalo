/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.quickchatapp;

/**
 *
 * @author sethu
 */
import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;
import org.json.simple.JSONObject;
import java.io.IOException;
import java.io.FileWriter;

public class Main {
    private static List<Message> sentMessages = new ArrayList<>(); //This stores successfully sent messages
    private static List<Message> storedMessages = new ArrayList<>();
    private static List<Message> discardedMessages = new ArrayList<>();
    private static List<String> messageHashes = new ArrayList<>();
    private static List<String> messageIds = new ArrayList<>(); // tracks the current logged in suer
    private static Login User;
    
    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);
        
        //Username contains an underscore and is no more than 5 characters long
        System.out.println("Welcome to Quick Chat App");
        System.out.print("Enter username(must contain _ and be at least 5 characters):");
        String username = scanner.nextLine();
        
        System.out.print("Enter password (must be at least 8 characters, number, special character):");
        String password = scanner.nextLine();
        
        System.out.print("Enter south african cell phone numner(with international code):");
       String cellphone = scanner.nextLine();
       
       System.out.print("Enter your first name: ");
       String firstName = scanner.nextLine();
       
       System.out.print("Enter your last name: ");
       String lastName = scanner.nextLine();
       
       // create and register the new user
       Login user = new Login(username, password, cellphone, firstName, lastName);
       
       System.out.println(user.registerUser());
       
       //login Phase
       
       System.out.println("\nLogin To Quick Chat");
       System.out.print("Enter username:");
       String loginUsername = scanner.nextLine();
       
       System.out.print("Enter Password: ");
       String loginPassword = scanner.nextLine();
       
       boolean loginStatus = user.loginUser(loginUsername, loginPassword);
       System.out.println(user.returnLoginStatus(loginStatus));
       
       // will exit if login fails
       if (!loginStatus){
           System.exit(0);
       }
       
       // chat Application
       System.out.println("\nWelcome to Quick Chat."); // the displaying of the welcome message
       
       System.out.print("How many messages would you like to send?");
       int messageCount = Integer.parseInt(scanner.nextLine());
       int messageSent = 0;
       
       while(true){
           System.out.println("\nMenu:");
           System.out.println("1) Send Messages");
           System.out.println("2) Show recently sent messages");
           System.out.println("3 Quit");
           System.out.print("Choose an Option: ");
           
           int choice = Integer.parseInt(scanner.nextLine());
           
           switch (choice){ // Handles the user selection menu
               case 1:
                   if (messageSent >= messageCount){
                       System.out.println("You have reached your limit");
                   
                   break;
           }
           
           System.out.print("Enter recipient cell phone number(with international code):");
           String recipient = scanner.nextLine();
           
           System.out.print("Enter your message of (max 250 characters)");
           String messageText = scanner.nextLine(); // a short message that does not exceed 250 words
           
           Message msg = new Message(recipient, messageText);
           String sendResult = msg.sentMessage();
           
           if (sendResult.equals("Message Sent")){
               System.out.println("Choose An Option:");
               System.out.println("1) Send Message");
               System.out.println("2) Discard Message");
               System.out.println("3) Store Message To Send Later");
               System.out.print("Your Choice:");
               
               int sendChoice = Integer.parseInt(scanner.nextLine());
               
               switch (sendChoice){
                   case 1:
                       sentMessages.add(msg);
                       messageHashes.add(msg.createMessageHash());
                       messageIds.add(msg.getMessageId());
                           messageSent++;
                           System.out.println("Message send successfully!!!");
                           break;
                           
                   case 2: 
                       discardedMessages.add(msg);
                       System.out.println("Message discard");
                   break;
                   
                   case 3: storedMessages.add(msg);
                   storeMessageToJSON(msg);
                   System.out.println("Message stored for later");
                   break;
               }
           }else { // Displays an error message if validation fails
               System.out.println(sendResult);
           }
           break;
           
           case 2: 
                System.out.println("Coming Soon!!!");
                break;
                
            case 3: 
                System.out.println("Goodbye!");
                System.exit(0); // the application should run until the user selects quit to exit
                break;
                
                default:
                System.out.println("Invalid choice. please try again");
       }
    }
    }
    
    private static void  messageOperationsMenu(Scanner scanner){
        while (true) {
            System.out.println("\nMessage Operations:");
            System.out.println("1) Display sender and recipient of all messages");
            
            System.out.println("2) Display longest sent message");
            System.out.println("3) Search for messages by ID");
            System.out.println("4) Search messages by recipient");
            System.out.println("5) Delete message by hash");
            System.out.println("6) Display full report of all sent messages");
            System.out.println("7) Back to Main Menu");
            
            System.out.println("Choose an option: ");
            
            int choice = Integer.parseInt(scanner.nextLine());
            
            switch (choice){
                case 1:
                       displaySendersAndRecipients();
                       break;
                case 2: 
                       displayLongestMessage();
                       break;
                case 3:
                       System.out.print("Enter message ID to search");
                       String searchId = scanner.nextLine();
                       searchByMessageId(searchId);
                       break;
                case 4: 
                       System.out.print("Enter recipient by search: ");
                       String recipient = scanner.nextLine();
                       searchByRecipient(recipient);
                       break;
                case 5:
                       System.out.print("Enter message hash to delete");
                       String hash = scanner.nextLine();
                       deleteByHash(hash);
                       break;
                case 6:
                        displayFullReport(User);
                        break;
                case 7:
                    return;
                default:
                    System.out.println("Invalid choice, please try again!!!");
            }
        }
    }
    // displays sender and recipient information for all sent messages
    private static void displaySendersAndRecipients(){
        if (sentMessages.isEmpty()){
            System.out.println("no messages sent yet!");
            return;
        }
        
        System.out.println("\nSender and recipients of all sent messages:");
        for (Message msg : sentMessages){
            System.out.println("from: " + User.getFirstName()+ " " + User.getLastName() + "(" + msg.getSender() + ")To:" + msg.getRecipient());
        }
    }
    
    private static void displayLongestMessage(){
        if (sentMessages.isEmpty()){
            System.out.println("No messages sent yet!");
            return;
        }
        
        Message longest = sentMessages.get(0);
        for (Message msg : sentMessages){
            if (msg.getContent().length() > longest.getContent().length()){
                longest = msg;
            }
        }
        
        System.out.println("\nLongest Message:");
        System.out.println("ID:" + longest.getMessageId());
        System.out.println("Recipient:" + longest.getRecipient());
        System.out.println("Content:" + longest.getContent());
        System.out.println("Length:" + longest.getContent().length() + "characters");
    }
    
    private static void searchByMessageId(String messageId){
        boolean found = false;
        for (Message msg : sentMessages){
            if (msg.getMessageId().equals(messageId)){
                System.out.println("\nMessage Found:");
                System.out.println("Recipient: " + msg.getRecipient());
                System.out.println("Content: " + msg.getContent());
                System.out.println("Hash: " + msg.createMessageHash());
                found = true;
                break;
            }
        }
        if (!found){
            System.out.println("No message found with ID " + messageId);
        }
    }
    
    private static void searchByRecipient(String recipient){
        List<Message> matches = new ArrayList<>();
        for (Message msg : sentMessages){
            if (msg.getRecipient().equals(recipient)){
                matches.add(msg);
            }
        }
         if (matches.isEmpty()){
        System.out.println("No messages found for recipient:" + recipient);
        return;
      }
         
         System.out.println("\nMessages sent to " + recipient + ":");
         for (Message msg : matches){
             System.out.println("ID: " + msg.getMessageId());
             System.out.println("Content: " + msg.getContent());
             System.out.println("Hash: " + msg.createMessageHash());
             System.out.println("------");
         }
    }
    
    private static void deleteByHash(String hash){
        boolean removed = false;
        for (int i = 0; i <sentMessages.size(); i++){
            if (sentMessages.get(i).createMessageHash().equals(hash)){
                sentMessages.remove(i);
                 messageHashes.remove(i);
                  messageIds.remove(i);
                  removed = true;
                   System.out.println("Message with hash " + hash + "deleted successfully");
                   break;
            }
        }
        
        if (!removed){
            System.out.println("No messages found with hash: " + hash);
        }
    }
    
    private static void displayFullReport(Login user){
        if (sentMessages.isEmpty()){
            System.out.println("no messages sent yet!!");
            return;
        }
        
        System.out.println("\nFull report of all sent messages:");
        System.out.println("Total Messages: " + sentMessages.size());
        System.out.println("-----------------------------------");
        
        for (Message msg : sentMessages){
            System.out.println("Message ID: " + msg.getMessageId());
            System.out.println("Sender: " + user.getFirstName() + " " + user.getLastName() + "(" + msg.getSender()+ ")");
            System.out.println("Recipient: " + msg.getRecipient());
            System.out.println("Content: " + msg.getContent());
            System.out.println("Hash: " + msg.createMessageHash());
            System.out.println("Length: " + msg.getContent().length() + "characters");
            System.out.println("-----------------------------------");
        }
    }
      
    private static void storeMessageToJSON(Message message){
        JSONObject messageObj = new JSONObject();
        messageObj.put("messageId", message.getMessageId());
         messageObj.put("sender", message.getSender());
          messageObj.put("recipient", message.getRecipient());
           messageObj.put("content", message.getContent());
            messageObj.put("hash", message.createMessageHash());
            
            try (FileWriter file = new FileWriter("stored_messages.json", true)){
                file.write(messageObj.toJSONString() + "\n");
                file.flush();
            } catch (IOException e){
                e.printStackTrace();
            }
    }
    
}

